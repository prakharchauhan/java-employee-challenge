package com.reliaquest.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.UUID;

public class EmployeeInput {

    private UUID id;  

    @JsonProperty("employee_name")
    private String name;

    @JsonProperty("employee_salary")
    private Integer salary;

    @JsonProperty("employee_age")
    private Integer age;

    @JsonProperty("employee_title")
    private String title;

     
    public UUID getId() { 
        return id; 
        }
    public void setId(UUID id) { 
        this.id = id; 
        }
    public String getName() { 
        return name; 
        }
    public Integer getSalary() { 
        return salary; 
        }
    public Integer getAge() { 
        return age; 
        }
    public String getTitle() { 
        return title; 
        }

    public void setName(String name) { 
        this.name = name; 
        }
    public void setSalary(Integer salary) { 
        this.salary = salary; 
        }
    public void setAge(Integer age) { 
        this.age = age; 
        }
    public void setTitle(String title) { 
        this.title = title; 
        }
}
