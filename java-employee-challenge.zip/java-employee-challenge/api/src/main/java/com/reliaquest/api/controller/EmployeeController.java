package com.reliaquest.api.controller;

import com.reliaquest.api.model.Employee;
import com.reliaquest.api.model.EmployeeInput;
import com.reliaquest.api.service.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController implements IEmployeeController<Employee, EmployeeInput> {

    private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public ResponseEntity<List<Employee>> getAllEmployees() {
        logger.info("Getting all employees.");
        List<Employee> employees = employeeService.getAllEmployees();
        if (employees.isEmpty()) {
            logger.warn("No employees found.");
        }
        return ResponseEntity.ok(employees);
    }

    @Override
    public ResponseEntity<List<Employee>> getEmployeesByNameSearch(@PathVariable String searchString) {
        logger.info("Searching for employees with name containing: {}", searchString);
        List<Employee> employees = employeeService.getEmployeesByNameSearch(searchString);
        return ResponseEntity.ok(employees);
    }

    @Override
    public ResponseEntity<Employee> getEmployeeById(@PathVariable String id) {
        logger.info("Getting employee by ID: {}", id);
        Employee employee = employeeService.getEmployeeById(id);
        if (employee == null) {
            logger.warn("No employee found with ID: {}", id);
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(employee);
    }

    @Override
    public ResponseEntity<Integer> getHighestSalaryOfEmployees() {
        logger.info("getting highest salary of employees.");
        return ResponseEntity.ok(employeeService.getHighestSalaryOfEmployees());
    }

    @Override
    public ResponseEntity<List<String>> getTopTenHighestEarningEmployeeNames() {
        logger.info("Getting top 10 highest-earning employees.");
        return ResponseEntity.ok(employeeService.getTopTenHighestEarningEmployeeNames());
    }

    @Override
    public ResponseEntity<Employee> createEmployee(@RequestBody EmployeeInput employeeInput) {
        logger.info("Creating new employee: {}", employeeInput.getName());
        Employee employee = employeeService.createEmployee(employeeInput);
        if (employee == null) {
            logger.error("Failed to create employee.");
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(employee);
    }

    @Override
    public ResponseEntity<String> deleteEmployeeById(@PathVariable String id) {
        logger.info("Deleting employee with ID: {}", id);
        String response = employeeService.deleteEmployeeById(id);
        if (response.contains("Failed")) {
            logger.error("Failed to delete employee with ID: {}", id);
            return ResponseEntity.badRequest().body(response);
        }
        return ResponseEntity.ok(response);
    }
}
