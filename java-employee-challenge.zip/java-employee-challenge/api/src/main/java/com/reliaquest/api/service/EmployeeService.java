package com.reliaquest.api.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.reliaquest.api.model.Employee;
import com.reliaquest.api.model.EmployeeInput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Arrays;
import java.util.Comparator;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    private static final Logger logger = LoggerFactory.getLogger(EmployeeService.class);
    private static final String MOCK_API_BASE_URL = "http://localhost:8112/api/v1/employee";
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public EmployeeService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        this.objectMapper = new ObjectMapper();
    }

    public List<Employee> getAllEmployees() {
        logger.info("Fetching all employees from {}", MOCK_API_BASE_URL);
        try {
            ResponseEntity<String> rawResponse = restTemplate.getForEntity(MOCK_API_BASE_URL, String.class);
            logger.info("Raw API Response: {}", rawResponse.getBody());

            JsonNode rootNode = objectMapper.readTree(rawResponse.getBody());
            JsonNode dataNode = rootNode.path("data");

            if (dataNode.isMissingNode() || !dataNode.isArray()) {
                logger.error("Invalid response format: 'data' field is missing or not an array.");
                return List.of();
            }

            Employee[] employees = objectMapper.treeToValue(dataNode, Employee[].class);
            logger.info("Parsed employees: {}", Arrays.toString(employees));
            return Arrays.asList(employees);
        } catch (Exception e) {
            logger.error("Error fetching employees: {}", e.getMessage());
            return List.of();
        }
    }

    public List<Employee> getEmployeesByNameSearch(String searchString) {
        logger.info("Searching employees with name containing: {}", searchString);
        return getAllEmployees().stream()
                .filter(emp -> emp.getEmployeeName() != null && emp.getEmployeeName().toLowerCase().contains(searchString.toLowerCase()))
                .collect(Collectors.toList());
    }

    public Employee getEmployeeById(String id) {
        logger.info("Fetching employee by ID: {}", id);
        try {
            UUID uuid = UUID.fromString(id);
            String url = MOCK_API_BASE_URL + "/" + uuid;
            ResponseEntity<String> rawResponse = restTemplate.getForEntity(url, String.class);
            logger.info("Raw Mock API Response for ID {}: {}", id, rawResponse.getBody());

            if (!rawResponse.getStatusCode().is2xxSuccessful()) {
                logger.warn("Failed to fetch employee with ID: {}. Status: {}", id, rawResponse.getStatusCode());
                return null;
            }

            JsonNode rootNode = objectMapper.readTree(rawResponse.getBody());
            JsonNode dataNode = rootNode.path("data");

            if (dataNode.isMissingNode() || dataNode.isNull()) {
                logger.warn("No employee found in response for ID: {}", id);
                return null;
            }

            Employee employee = objectMapper.treeToValue(dataNode, Employee.class);
            logger.info("Employee found: {}", employee.getEmployeeName());
            return employee;
        } catch (IllegalArgumentException e) {
            logger.error("Invalid UUID format: {}", id);
            return null;
        } catch (Exception e) {
            logger.error("Error fetching employee by ID {}: {}", id, e.getMessage());
            return null;
        }
    }

    public Integer getHighestSalaryOfEmployees() {
        logger.info("Fetching highest salary of employees.");
        return getAllEmployees().stream()
                .map(Employee::getEmployeeSalary)
                .filter(salary -> salary != null)
                .max(Integer::compareTo)
                .orElse(0);
    }

    public List<String> getTopTenHighestEarningEmployeeNames() {
        logger.info("Fetching top 10 highest-earning employees.");
        return getAllEmployees().stream()
                .sorted(Comparator.comparing(Employee::getEmployeeSalary, Comparator.nullsLast(Comparator.reverseOrder())))
                .limit(10)
                .map(Employee::getEmployeeName)
                .collect(Collectors.toList());
    }

    public Employee createEmployee(EmployeeInput employeeInput) {
        logger.info("Creating new employee: {}", employeeInput.getName());
        try {
            Employee createdEmployee = restTemplate.postForObject(MOCK_API_BASE_URL, employeeInput, Employee.class);
            logger.info("Employee created successfully: {}", createdEmployee != null ? createdEmployee.getEmployeeName() : "Unknown");
            return createdEmployee;
        } catch (Exception e) {
            logger.error("Error creating employee: {}", e.getMessage());
            return null;
        }
    }

    public String deleteEmployeeById(String id) {
        logger.info("Deleting employee with ID: {}", id);
        try {
            UUID uuid = UUID.fromString(id);
            String url = MOCK_API_BASE_URL + "/" + uuid;
            restTemplate.delete(url);
            logger.info("Employee with ID {} deleted successfully.", id);
            return "Employee with ID " + id + " deleted successfully.";
        } catch (IllegalArgumentException e) {
            logger.error("Invalid UUID format: {}", id);
            return "Failed to delete employee: Invalid UUID format.";
        } catch (Exception e) {
            logger.error("Error deleting employee with ID {}: {}", id, e.getMessage());
            return "Failed to delete employee with ID " + id;
        }
    }
}
