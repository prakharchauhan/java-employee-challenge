package com.reliaquest.api.controller;

import com.reliaquest.api.model.Employee;
import com.reliaquest.api.model.EmployeeInput;
import com.reliaquest.api.service.EmployeeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class EmployeeControllerTest {

    private MockMvc mockMvc;

    @Mock
    private EmployeeService employeeService;

    @InjectMocks
    private EmployeeController employeeController;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(employeeController).build();
    }

    @Test
    void testGetAllEmployees() throws Exception {
        Employee employee = new Employee();
        employee.setEmployeeName("Prakhar Chauhan");
        employee.setEmployeeSalary(120000);
        employee.setEmployeeAge(27);
        employee.setEmployeeTitle("Software Engineer");
        employee.setEmployeeEmail("prakhar@reliaquest.com");

        when(employeeService.getAllEmployees()).thenReturn(List.of(employee));

        mockMvc.perform(get("/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].employee_name").value("Prakhar Chauhan"))
                .andExpect(jsonPath("$[0].employee_salary").value(120000))
                .andExpect(jsonPath("$[0].employee_age").value(27))
                .andExpect(jsonPath("$[0].employee_title").value("Software Engineer"))
                .andExpect(jsonPath("$[0].employee_email").value("prakhar@reliaquest.com"));
    }

    @Test
    void testGetEmployeesByNameSearch() throws Exception {
        when(employeeService.getEmployeesByNameSearch("Prakhar"))
                .thenReturn(List.of(new Employee()));

        mockMvc.perform(get("/employees/search/Prakhar"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetEmployeeById() throws Exception {
        Employee employee = new Employee();
        employee.setEmployeeName("Prakhar Chauhan");

        when(employeeService.getEmployeeById(anyString())).thenReturn(employee);

        mockMvc.perform(get("/employees/48dcbf32-9713-4a7e-9c4f-3d9875d12163"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.employee_name").value("Prakhar Chauhan"));
    }

    @Test
    void testGetHighestSalaryOfEmployees() throws Exception {
        when(employeeService.getHighestSalaryOfEmployees()).thenReturn(120000);

        mockMvc.perform(get("/employees/highestSalary"))
                .andExpect(status().isOk())
                .andExpect(content().string("120000"));
    }

    @Test
    void testGetTopTenHighestEarningEmployeeNames() throws Exception {
        when(employeeService.getTopTenHighestEarningEmployeeNames())
                .thenReturn(List.of("Prakhar Chauhan"));

        mockMvc.perform(get("/employees/topTenHighestEarningEmployeeNames"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").value("Prakhar Chauhan"));
    }

    @Test
    void testCreateEmployee() throws Exception {
        EmployeeInput input = new EmployeeInput();
        input.setName("Prakhar Chauhan");
        input.setSalary(120000);
        input.setAge(27);
        input.setTitle("Software Engineer");

        Employee createdEmployee = new Employee();
        createdEmployee.setEmployeeName("Prakhar Chauhan");

        when(employeeService.createEmployee(any(EmployeeInput.class))).thenReturn(createdEmployee);

        mockMvc.perform(post("/employees")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            {
                                "name": "Prakhar Chauhan",
                                "salary": 120000,
                                "age": 27,
                                "title": "Software Engineer"
                            }
                        """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.employee_name").value("Prakhar Chauhan"));
    }

    @Test
    void testDeleteEmployeeById() throws Exception {
        when(employeeService.deleteEmployeeById(anyString())).thenReturn("Employee deleted successfully.");

        mockMvc.perform(delete("/employees/48dcbf32-9713-4a7e-9c4f-3d9875d12163"))
                .andExpect(status().isOk())
                .andExpect(content().string("Employee deleted successfully."));
    }
}
